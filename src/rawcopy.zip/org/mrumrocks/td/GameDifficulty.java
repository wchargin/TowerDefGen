package org.mrumrocks.td;

/**
 * The various difficulty levels of a game.
 * 
 * @author William Chargin
 * 
 */
public enum GameDifficulty {
	EASY("Easy", 0.5), MEDIUM("Medium", 1), HARD("Hard", 2);

	private GameDifficulty(String name, double speedModifier) {
		this.name = name;
		this.speedModifier = speedModifier;
	}

	public final String name;
	public final double speedModifier;

}
