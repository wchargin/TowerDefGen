package org.mrumrocks.td;

import org.mrumrocks.td.maps.MapLevel;

/**
 * A collection of information about the game.
 * 
 * @author William Chargin
 * 
 */
public class GameInfoNode {

	/**
	 * The map selected for the game.
	 */
	public MapLevel level;

	/**
	 * The difficulty level selected for the game.
	 */
	public GameDifficulty difficulty;

}
