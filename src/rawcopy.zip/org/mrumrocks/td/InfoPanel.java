package org.mrumrocks.td;

import jgame.Context;
import jgame.GContainer;
import jgame.GMessage;
import jgame.listener.ButtonListener;

import org.mrumrocks.td.towers.Tower;

public class InfoPanel extends GContainer {

	private UpgradeHandler handler;

	public InfoPanel(UpgradeHandler uh) {
		setSize(800, 600 - 480);
		handler = uh;
	}

	public void setSelectedTower(Tower tower) {
		removeAllChildren();
		if (tower != null)
			add(generateUpgradeContainer(tower));
	}

	private GContainer generateUpgradeContainer(final Tower t) {
		final GContainer c = new GContainer();
		c.setSize(getWidth(), getHeight());
		c.setAnchorTopLeft();
		GMessage msgCurrentLevel = new GMessage("Current level: "
				+ t.getLevel());
		msgCurrentLevel.setFontSize(24);
		msgCurrentLevel.setBounds(0, 5, 100, 24);
		msgCurrentLevel.setAnchorTopLeft();
		c.add(msgCurrentLevel);

		if (t.hasUpgradeForLevel(t.getLevel() + 1)) {
			GMessage msgUpgradeCost = new GMessage("Upgrade cost: "
					+ t.getUpgradeCostForLevel(t.getLevel() + 1));
			msgUpgradeCost.setAnchorTopLeft();
			c.add(msgUpgradeCost);
			msgUpgradeCost.setBounds(0, 24 + 5 + 5, 100, 24);
			msgUpgradeCost.setFontSize(24);

			final Button upgrade = new Button("Purchase");
			c.add(upgrade);
			upgrade.setLocation(115, 85);

			upgrade.addListener(new ButtonListener() {
				@Override
				public void mouseClicked(Context context) {
					if (handler.canAfford(t.getUpgradeCostForLevel(t.getLevel() + 1))) {
						removeAllChildren();
						handler.purchaseUpgrade(t.getUpgradeCostForLevel(t
								.getLevel() + 1));
						t.doUpgrade(t.getLevel() + 1);
						add(generateUpgradeContainer(t));
					} else {
						upgrade.setText("Not enough money");
					}
				}
			});
		} else {
			GMessage msgNoUpgrades = new GMessage("No upgrades available");
			msgNoUpgrades.setAnchorTopLeft();
			c.add(msgNoUpgrades);
			msgNoUpgrades.setBounds(0, 24 + 5 + 5, 100, 24);
			msgNoUpgrades.setFontSize(24);
		}
		return c;
	}
}
