package org.mrumrocks.td;

public interface UpgradeHandler {

	/**
	 * Tests whether an upgrade of the given cost is affordable.
	 * 
	 * @param cost
	 *            the cost to check
	 * @return whether the upgrade can be afforded
	 */
	public boolean canAfford(int cost);

	/**
	 * Purchases an upgrade for the given cost.
	 * 
	 * @param cost
	 *            the cost of the upgrade
	 */
	public void purchaseUpgrade(int cost);

}
