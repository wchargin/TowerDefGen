package org.mrumrocks.td;

/**
 * This enumeration represents the different types of views in the tower defense
 * game. The view can be switched by calling
 * {@link jgame.Context#setCurrentGameView(Object) setCurrentGameView} on a
 * {@code Context} object with one of the values of this enumeration.
 * 
 * @author William Chargin
 * 
 */
public enum ViewType {

	/**
	 * The main menu of the game.
	 */
	MAIN_MENU,

	/**
	 * The main game view.
	 */
	GAME,

	/**
	 * The help menu.
	 */
	HELP;

}
