package org.mrumrocks.td.enemies;

import java.awt.Image;

import jgame.GSprite;

import org.mrumrocks.td.GameView;

public abstract class Enemy extends GSprite {

	private int health;
	public final int money;
	public final int slowness;

	public Enemy(Image image, int health, int money, int slowness) {
		super(image);
		this.health = health;
		this.money = money;
		this.slowness = slowness;
	}

	public int getHealth() {
		return health;
	}

	/**
	 * Gets the slowness (the time spent between waypoints) of this enemy.
	 * 
	 * @return the slowness
	 */
	public int getSlowness() {
		return slowness;
	}

	public void damage(int damage) {
		if ((health -= damage) <= 0) {
			getFirstAncestorOf(GameView.class).enemyKilled(this);
			removeSelf();
		}
	}
}
