package org.mrumrocks.td.maps;

import java.awt.Image;
import java.awt.Point;
import java.awt.Polygon;

import jgame.GContainer;
import jgame.GObject;
import jgame.GSprite;
import jgame.controller.PolygonController;

import org.mrumrocks.td.Base;
import org.mrumrocks.td.Button;
import org.mrumrocks.td.GameDifficulty;
import org.mrumrocks.td.enemies.Enemy;

public abstract class MapLevel extends GContainer {

	/**
	 * The thumbnail for the map.
	 */
	private final Image thumb;

	/**
	 * The (approximate) width of the path, in pixels.
	 */
	protected double pathWidth = 50;

	public boolean isOnPath(GObject object) {
		Polygon poly = createWaypointPolygon();
		for (int i = 0; i < poly.npoints; i++) {
			Point p = new Point(poly.xpoints[i], poly.ypoints[i]);
			if (object.distanceTo(p) <= pathWidth) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Creates the level with the given background.
	 * 
	 * @param background
	 *            the background sprite
	 */
	public MapLevel(Image background, Image thumb) {
		super(new GSprite(background));
		this.thumb = thumb;
		Base b = new Base();
		add(b);
		Polygon p = createWaypointPolygon();
		b.setLocation(p.xpoints[p.npoints - 1], p.ypoints[p.npoints - 1]);
	}

	/**
	 * Creates and returns a polygon representing the waypoint path of this
	 * level.
	 * 
	 * @return the waypoint path
	 */
	protected abstract Polygon createWaypointPolygon();

	/**
	 * Initializes the given enemy. This adds the enemy to the level and
	 * configures it to use the level's waypoints.
	 * 
	 * @param enemy
	 *            the enemy to initialize
	 */
	public void initializeEnemy(Enemy enemy, GameDifficulty difficulty) {
		// Get the polygon (subclasses must implement this).
		Polygon polygon = createWaypointPolygon();

		// Create a controller.
		PolygonController pc = new PolygonController(polygon);

		// Rotate to move along path smoothly.
		pc.setRotateToFollow(true);

		// Set the speed.
		pc.setMaxSpeed(enemy.getSlowness() / difficulty.speedModifier);

		// Add the controller.
		enemy.addController(pc);

		// Initialize.
		pc.goToStart(enemy);
		
		// Finally, add the enemy to the level.
		add(enemy);
	}

	public Button createThumbnailButton() {
		Button b = new Button(new String());
		GSprite object = new GSprite(thumb);
		b.setSize(object.getWidth(), object.getHeight());
		object.setScale(0.9);
		b.addAtCenter(object);
		return b;
	}
}
