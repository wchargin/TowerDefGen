package org.mrumrocks.td.projectiles;

import java.awt.Image;
import java.util.ArrayList;
import java.util.List;

import jgame.Context;
import jgame.GObject;
import jgame.GSprite;
import jgame.listener.BoundaryRemovalListener;
import jgame.listener.HitTestListener;

import org.mrumrocks.td.enemies.Enemy;

public class Projectile extends GSprite {

	private List<Enemy> alreadyHit = new ArrayList<Enemy>();

	private int health;

	public Projectile(Image image, int startingHealth) {
		super(image);
		health = startingHealth;

		addListener(new HitTestListener(Enemy.class) {
			@Override
			public void invoke(GObject target, Context context) {
				for (Enemy e : context.hitTestClass(Enemy.class)) {
					alreadyHit.add(e);
					int damage = Math.min(health, e.getHealth());
					System.out.println(damage);
					e.damage(damage);
					if ((health -= damage) <= 0) {
						removeSelf();
						break;
					}
				}
			}
		});

		addListener(new BoundaryRemovalListener());
	}

}
