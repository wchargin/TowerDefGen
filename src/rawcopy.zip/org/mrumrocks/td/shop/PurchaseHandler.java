package org.mrumrocks.td.shop;

import org.mrumrocks.td.towers.Tower;

/**
 * An interface between the shop panel and the cash system.
 * 
 * @author William Chargin
 * 
 */
public interface PurchaseHandler {

	/**
	 * Determines whether a purchase of the given cost is allowed.
	 * 
	 * @param cost
	 *            the cost to check
	 * @return {@code true} if the purchase is allowed, or {@code false} if
	 *         it is not
	 */
	public boolean canPurchase(int cost);

	/**
	 * Performs a purchase for the given tower. This should add the turret to
	 * the correct area and initiate a drag-like action to allow the user to
	 * place the turret.
	 * 
	 * @param tower
	 *            the tower to purchase
	 */
	public void performPurchase(Tower tower, int cost);

}
