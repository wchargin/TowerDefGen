package org.mrumrocks.td.shop;

import org.mrumrocks.td.towers.Tower;

/**
 * An interface to allow for tower creation at runtime (for example, for shop
 * buttons).
 * 
 * @author William Chargin
 * 
 */
public interface TowerGenerator {

	/**
	 * Creates and returns a tower.
	 * 
	 * @return the newly created tower
	 */
	public Tower generateTower();

}
