package org.mrumrocks.td.towers;

import java.awt.Image;
import java.util.List;

import org.mrumrocks.td.enemies.Enemy;
import org.mrumrocks.td.projectiles.Projectile;

import jgame.Context;
import jgame.GObject;
import jgame.GSprite;
import jgame.controller.ConstantMovementController;
import jgame.listener.FrameListener;

/**
 * A tower that works on a fire-delay timer.
 * 
 * @author William Chargin
 * 
 */
public abstract class Tower extends GSprite {

	/**
	 * Whether this turret has been activated.
	 */
	private boolean activated;

	/**
	 * Activates this turret.
	 */
	public void activate() {
		activated = true;
	}

	/**
	 * The current level of this turret.
	 */
	private int level = 0;

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	/**
	 * Creates the projectile to be fired by this tower. The returned projectile
	 * should be positioned correctly, but should not have any movement
	 * controllers.
	 * 
	 * @return the projectile
	 */
	protected abstract Projectile createProjectile(Context c);

	/**
	 * Fires the tower, if firing is currently possible.
	 */
	public void fire(Context c) {
		if (!activated) {
			return;
		}

		// use while loop so we can fire more than once, if allowed
		while (canFire(c)) {
			Projectile projectile = createProjectile(c);
			addSibling(projectile);

			double speed = getProjectileSpeed(c);
			double angle = getFiringAngle(c);

			setRotation(angle);
			projectile.setRotation(angle);

			projectile.addController(ConstantMovementController.createPolar(
					speed, angle));

			towerFired(c);
		}
	}

	public Tower(Image image) {
		super(image);
		addListener(new FrameListener() {
			@Override
			public void invoke(GObject target, Context context) {
				fire(context);
				if (timer >= 0) {
					timer--;
				}
			}
		});
	}

	/**
	 * Gets the closest enemy within the given maximum range.
	 * 
	 * @param c
	 *            the relevant context
	 * @param maxRange
	 *            the maximum range
	 * @return the closest enemy, or {@code null} if there are no enemies in
	 *         range
	 */
	public Enemy getClosestEnemy(Context c, double maxRange) {
		List<Enemy> enemies = c.getInstancesOfClass(Enemy.class);

		double minRange = maxRange;
		Enemy closest = null;

		for (Enemy e : enemies) {
			double distance = distanceTo(e);
			if (distance < minRange) {
				closest = e;
				minRange = distance;
			}
		}

		return closest;
	}

	/**
	 * Gets the speed at which this tower should fire a projectile, in pixels
	 * per frame.
	 * 
	 * @return the firing speed
	 */
	protected abstract double getProjectileSpeed(Context c);

	/**
	 * Determines whether the turret is upgradable to the given level, where
	 * {@code 1} is the first upgrade.
	 * 
	 * @param level
	 *            the level to check
	 * @return {@code true} if the turret can be upgraded (or has already been),
	 *         or {@code false} otherwise
	 */
	public abstract boolean hasUpgradeForLevel(int level);

	/**
	 * Upgrades the turret to the given level.
	 * 
	 * @param level
	 *            the level to upgrade to
	 */
	public abstract void doUpgrade(int level);

	/**
	 * Calculates the upgrade cost for the given level.
	 * 
	 * @param level
	 *            the level to upgrade to
	 * @return the upgrade cost
	 */
	public abstract int getUpgradeCostForLevel(int level);

	/**
	 * The timer.
	 */
	private int timer = 0;

	protected double getFiringAngle(Context c) {
		return angleTo(getClosestEnemy(c, getRange(c)));
	}

	protected boolean canFire(Context c) {
		return timer <= 0 && getClosestEnemy(c, getRange(c)) != null;
	}

	/**
	 * Gets the delay for firing the tower.
	 * 
	 * @param c
	 *            the relevant context
	 * @return the delay, in frames
	 */
	protected abstract int getFiringDelay(Context c);

	/**
	 * Gets the maximum range of this tower.
	 * 
	 * @param c
	 *            the relevant context
	 * @return the max range, in pixels
	 */
	protected abstract int getRange(Context c);

	protected void towerFired(Context c) {
		timer = getFiringDelay(c);
	}

}
